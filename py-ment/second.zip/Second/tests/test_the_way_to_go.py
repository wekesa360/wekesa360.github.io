import os 
import testbook
path = os.getcwd()
_path = "{}/the_way_to_go.ipynb".format(path)

@testbook.testbook(_path, execute=True)
def test_plus_minus(tb):
    func = tb.ref("plus_minus")
    arr = [1,1,0,-1,-1]
    assert func(arr) == [0.400000, 0.400000, 0.200000]

@testbook.testbook(_path, execute=True)
def test_two_sum(tb):
    func2 = tb.ref("two_sum")
    nums = [2, 7, 11, 15]
    target = 9
    assert func2(nums, target) == [0, 1]
    
@testbook.testbook(_path, execute=True)
def test_fizz_buzz(tb):
    func3 = tb.ref("fizz_buzz")
    n = 15
    output = ["1","2","Fizz","4","Buzz","Fizz","7", "8","Fizz","Buzz","11","Fizz","13","14","FizzBuzz"]
    assert func3(n) == output

@testbook.testbook(_path, execute=True)
def test_vowel_count(tb):
    func4 = tb.ref("vowel_count")
    assert func4("Sandra") == 2
    assert func4("village") == 3
    

@testbook.testbook(_path, execute=True)
def test_height_checker(tb):
    func5 = tb.ref("height_checker")
    heights = [1,1,4,2,1,3]
    assert func5(heights) == 3

@testbook.testbook(_path, execute=True)
def test_fib(tb):
    func6 = tb.ref("fib")
    N = 4
    assert func6(N) == 3
    assert func6(2) == 1
    assert func6(3) == 2
