## Requirements
1. Jupyter notebook
2. Python interpreter of version 3.6 and above

```
pip install -r requirements.txt
```

## Usage
Unzip and try to solve the questions.



